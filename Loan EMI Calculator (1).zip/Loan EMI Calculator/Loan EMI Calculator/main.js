function setInitialValue() {
  console.log('setInitialValue');
  computeResults();
}
function getloanAmount() {
  return document.getElementById("amount").value;
}
function getloanInterestRate() {
  return document.getElementById("interest").value;
}
function getloanTenure() {
  return document.getElementById("years").value;
}
function getmonthlyEmi() {
  const principleamount = getloanAmount();
  const monthlyintestrate = getmonthlyinterestrate(getloanInterestRate());
  const tenureyearly = getloanTenure() * 12;
  const emi = principleamount * monthlyintestrate *
    (Math.pow(1 + monthlyintestrate, tenureyearly) /
      (Math.pow(1 + monthlyintestrate, tenureyearly) - 1));
  return emi;
}
function getmonthlyinterestrate(loaninterestrate) {
  console.log('loaninterestrate:123', loaninterestrate);
  return loaninterestrate / 12 / 100;
}
function gettenuremonth() {
  return getloanTenure() * 12;
}
function computeResults() {
  console.log('computeResults');
  const totalInterest = (getmonthlyEmi() * getloanTenure() * 12 - getloanAmount()).toFixed(2);
  document.getElementById("totalInterest").innerHTML = totalInterest;
  const totalPayment = (getmonthlyEmi() * getloanTenure() * 12).toFixed();
  document.getElementById("totalPayment").innerHTML = totalPayment;
  const monthlyPayment = getmonthlyEmi().toFixed();
  document.getElementById("monthlyPayment").innerHTML = monthlyPayment;
  const tenureinmonth = gettenuremonth();
  const loanamount = getloanAmount();
  const monthlyinterest = getmonthlyinterestrate(getloanInterestRate());
  generatemonthlyemi(monthlyPayment, tenureinmonth, loanamount, monthlyinterest);
}
function generatemonthlyemi(monthlyemi, tenureinmonth, loanamount, monthlyinterest) {
  console.log('monthlyemi:', monthlyemi);
  console.log('tenureinmonth:', tenureinmonth);
  console.log('loanamount', loanamount);
  console.log('monthlyinterest', monthlyinterest);
  const data_array = [];
  let outstandingbalance = loanamount;
  for (let i = 0; i < tenureinmonth; i++) {
    console.log(typeof (monthlyemi));
    const my_object = {
      "openingbalance": outstandingbalance,
      "monthlyemi": (+monthlyemi).toFixed(),
      "principlepaid": (+monthlyemi - (+outstandingbalance * monthlyinterest)).toFixed(),
      "interestpaid": (+outstandingbalance * monthlyinterest).toFixed()
    };
    my_object.outstandingbalence = +outstandingbalance - my_object.principlepaid;
    outstandingbalance = (my_object.outstandingbalence);
    data_array.push(my_object);
  }
  console.table(data_array);




}
